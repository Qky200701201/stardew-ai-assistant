# 星露谷物语内存地址查找指南 (Cheat Engine)

## 第一步：安装并打开 Cheat Engine

下载: https://www.cheatengine.org/

## 第二步：连接游戏进程

1. 启动星露谷物语，进入任意场景
2. 打开 CE → 点击左上角电脑图标 → 选择 `Stardew Valley.exe` → 确定

## 第三步：扫描基础数值

### 找金币 (Gold)
1. 记住当前金币数（比如 500）
2. Value Type → **4 Bytes**
3. Exact Value → 输入 `500` → First Scan
4. 去矿洞或摘星果赚点钱（比如变成 510）
5. New Scan → Exact Value → `500` → Next Scan
6. 重复直到只剩 1-2 个地址
7. 右键地址 → **Show this address in the table** → 双击加入下方列表
8. 右键表格中的地址 → **Find out what writes to this address**
9. 赚钱触发写入 → 记下汇编代码中的指针地址

### 找血量 (Health)
同上流程，进矿洞被蝙蝠打一下改变血量来扫描。

### 找坐标 (PlayerX, PlayerY)
1. Value Type → **4 Bytes**
2. Unknown Type → Initial Value → First Scan
3. 移动到不同位置
4. Next Scan → Unknown Type → Initial Value → 搜索新值
5. 反复缩小范围

### 找时间 (Day / Hour)
1. Day: Exact Value → 输入天数 → Scan
2. 等一天过去 → Next Scan → 输入新天数
3. Hour: 被动的，时间自然流逝就会变

## 第四步：获取基址和偏移

找到地址后：
1. **右键地址 → Copy Address** 得到类似 `stardewValley.exe+1A2B3C`
2. 右键 → **Dissect allocated memory** 查看完整指针链
3. 或者在 CE 中右键地址 → **Find references to this address**

最终你会得到：
```
静态基址 = stardewValley.exe 的加载基址 (如 0x00400000)
偏移链 = [0xXXXX, 0xYYYY, ...]
```

## 第五步：填入 reader.py

把找到的值填入 CONFIG 区域：

```python
# 方式A：如果每个字段有独立地址
GAME_BASE_ADDRESS = 0x00400000  # CE 显示的基址
PLAYER_OFFSET = 0x1A2B3C        # 从基址到 PlayerData 的偏移
GOLD_OFFSET = 0x40              # PlayerData 内部 Gold 偏移
HEALTH_OFFSET = 0x44            # ...

# 方式B：用指针链（推荐，更稳定）
USE_STATIC_BASE = False
PLAYER_POINTER_CHAIN = [0x180, 0x2C0, 0x40]  # CE 找到的指针链
```

## 常用星露谷数据参考

| 数据 | 类型 | 说明 |
|------|------|------|
| 金币 | 4字节整数 | 0开始 |
| 血量 | 4字节整数 | 通常最大20 |
| 最大血量 | 4字节整数 | 可升级 |
| 天数 | 4字节整数 | 春季第1天=1 |
| 小时 | 4字节整数 | 6(早)=6, 20(晚)=20 |
| 分钟 | 4字节整数 | 0-59 |
| X坐标 | 4字节整数 | 农场约(-1,-1) |
| Y坐标 | 4字节整数 | 农场约(-1,-1) |
| 季节 | 4字节整数 | 0春1夏2秋3冬 |
| 星期 | 4字节整数 | 0周一6周日 |
