"""
AI 状态分析引擎 — 支持规则引擎和 LLM 两种模式
"""

import json
import os
from dataclasses import dataclass


SEASON_NAMES = ["春", "夏", "秋", "冬"]
DOW_NAMES = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
WEATHER_NAMES = ["晴天", "雨天", "暴风雪", "日食"]


@dataclass
class GameContext:
    """游戏上下文，供 AI 推理使用"""
    # 玩家状态
    health_pct: float
    gold: int
    tool: str = "锄头"
    weapon_damage: int = 0
    
    # 时间
    season: str = "春"
    day: int = 1
    hour: int = 6
    minute: int = 0
    day_of_week: str = "周一"
    
    # 位置
    location: str = "农场"
    
    # 环境（可扩展）
    weather: str = "晴天"
    in_dungeon: bool = False
    dungeon_floor: int = 0
    
    # 库存摘要
    crops_ready_to_harvest: int = 0
    seeds_in_inventory: int = 0
    food_in_inventory: int = 0
    bombs_in_inventory: int = 0
    
    # NPC 好感度（可选）
    npc_affection: dict = None  # {"Abigail": 200, ...}
    
    def __post_init__(self):
        if self.npc_affection is None:
            self.npc_affection = {}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 规则引擎分析器
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class RuleEngineAnalyzer:
    """基于规则的本地分析器，零延迟"""
    
    RULES = {
        "health_critical": {
            "condition": lambda c: c.health_pct < 20,
            "warning": "⚠️ 血量危险！仅剩 {:.0f}%，立即回城或吃药！",
            "urgency": "high"
        },
        "health_low": {
            "condition": lambda c: 20 <= c.health_pct < 50,
            "warning_template": "血量偏低 ({:.0f}%)，建议休息补充",
            "urgency": "medium"
        },
        "time_too_late": {
            "condition": lambda c: c.hour >= 21 or (c.hour == 20 and c.minute >= 30),
            "warning": "⏰ 太晚了！快回家，会晕倒丢钱！",
            "urgency": "high"
        },
        "time_warning": {
            "condition": lambda c: c.hour >= 19,
            "suggestion": "快10点了，考虑收工回家",
            "urgency": "low"
        },
        "new_day": {
            "condition": lambda c: c.hour == 6 and c.minute < 10,
            "suggestion": "新的一天开始了！先浇水 → 收割 → 喂动物 → 出门",
            "urgency": "low"
        },
        "low_gold": {
            "condition": lambda c: c.gold < 300,
            "suggestion": "金币紧张，建议卖作物或挖矿赚钱",
            "urgency": "low"
        },
        "rich_player": {
            "condition": lambda c: c.gold > 10000,
            "suggestion": "资金充裕！可以考虑买鸡/牛，或者升级工具",
            "urgency": "low"
        },
        "in_mine": {
            "condition": lambda c: c.in_dungeon and c.dungeon_floor > 0,
            "suggestion_template": "在矿井{}层，注意补给食物和火把",
            "urgency": "medium"
        },
        "no_seeds": {
            "condition": lambda c: c.seeds_in_inventory == 0 and c.location == "农场",
            "suggestion": "没有种子了，去鹈鹕镇Pierre商店买一些",
            "urgency": "low"
        },
        "no_bombs": {
            "condition": lambda c: c.bombs_in_inventory == 0 and c.in_dungeon,
            "suggestion": "没炸弹了！用剑清怪节省体力",
            "urgency": "medium"
        },
        "season_transition": {
            "condition": lambda c: c.day == 27 and c.hour >= 12,
            "suggestion_template": "{}季快结束了，记得把作物卖掉！",
            "urgency": "medium"
        },
        "friday_market": {
            "condition": lambda c: c.day_of_week == "周六" and c.season != "冬" and c.hour >= 9,
            "suggestion": "今天是周六集市日！去森林看看有什么稀有物品",
            "urgency": "low"
        }
    }
    
    def analyze(self, ctx: GameContext) -> dict:
        warnings = []
        suggestions = []
        urgency = "low"
        
        for rule_name, rule in self.RULES.items():
            try:
                cond = rule["condition"]
                # 处理需要访问 ctx 的 lambda
                if callable(cond):
                    if not cond(ctx):
                        continue
                
                if "warning" in rule:
                    msg = rule["warning"]
                    if "{:.0f}" in msg or "{}" in msg:
                        msg = msg.format(ctx.health_pct)
                    warnings.append(msg)
                    urgency = max(urgency, rule.get("urgency", "low"), key=lambda x: {"low": 0, "medium": 1, "high": 2}[x])
                
                if "warning_template" in rule:
                    msg = rule["warning_template"].format(ctx.health_pct)
                    warnings.append(msg)
                    urgency = max(urgency, rule.get("urgency", "low"), key=lambda x: {"low": 0, "medium": 1, "high": 2}[x])
                
                if "suggestion" in rule:
                    suggestions.append(rule["suggestion"])
                
                if "suggestion_template" in rule:
                    msg = rule["suggestion_template"].format(ctx.dungeon_floor if "dungeon_floor" in rule["suggestion_template"] else ctx.season)
                    suggestions.append(msg)
                    
            except Exception:
                continue
        
        return {
            "info": {
                "season": ctx.season,
                "day": ctx.day,
                "time": f"{ctx.hour}:{ctx.minute:02d}",
                "location": ctx.location,
                "health_pct": round(ctx.health_pct, 1),
                "gold": ctx.gold,
            },
            "warnings": warnings,
            "suggestions": suggestions[:5],  # 最多5条建议
            "urgency": urgency,
        }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LLM 分析器
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class LLMAnalyzer:
    """
    接入 LLM API 的深度分析器
    
    支持: OpenAI / Anthropic / 本地 Qwen/GLM
    """
    
    SYSTEM_PROMPT = """你是一个星露谷物语游戏助手。根据玩家提供的实时游戏状态JSON，给出简洁实用的建议。

输出格式（严格JSON）：
{
  "info": {
    "summary": "一句话总结当前局势"
  },
  "warnings": ["危险警告列表"],
  "suggestions": ["具体行动建议，最多5条"],
  "urgency": "low|medium|high",
  "priority_action": "当前最应该做的第一件事"
}

规则要点：
- 晚上9:30前必须回家，否则晕倒
- 春季第1天去河边钓鱼可获得鲑鱼种子
- 每周六有集市，可买到稀有物品
- 矿井每10层有一个宝箱层
- 保持工具升级，铁矿匠镇上有升级服务
- 农作物要每天浇水，枯萎后需重新种植
- 送NPC喜欢的礼物可以提升好感度解锁剧情
- 夏天种番茄和辣椒收益高，秋天南瓜最值钱
- 矿洞中炸弹可以炸开隐藏墙壁找到秘密房间
"""
    
    def __init__(self, api_provider="openai", api_key=None, base_url=None, model=None):
        self.provider = api_provider
        self.api_key = api_key or os.getenv(f"{api_provider.upper()}_API_KEY")
        self.base_url = base_url or os.getenv(f"{api_provider.upper()}_BASE_URL")
        self.model = model or ("gpt-4o-mini" if api_provider == "openai" else "qwen-max")
    
    def analyze(self, ctx: GameContext) -> dict:
        """调用 LLM 获取分析结果"""
        state_json = json.dumps({
            "health_pct": ctx.health_pct,
            "gold": ctx.gold,
            "tool": ctx.tool,
            "season": ctx.season,
            "day": ctx.day,
            "hour": ctx.hour,
            "minute": ctx.minute,
            "day_of_week": ctx.day_of_week,
            "location": ctx.location,
            "weather": ctx.weather,
            "in_dungeon": ctx.in_dungeon,
            "dungeon_floor": ctx.dungeon_floor,
            "crops_ready": ctx.crops_ready_to_harvest,
            "seeds": ctx.seeds_in_inventory,
            "food": ctx.food_in_inventory,
            "bombs": ctx.bombs_in_inventory,
            "npc_affection": ctx.npc_affection,
        }, ensure_ascii=False)
        
        user_prompt = f"""当前游戏状态：
{state_json}

请根据以上状态给出建议。如果某些数据缺失，基于已有信息推断。"""
        
        if self.provider == "openai":
            return self._call_openai(user_prompt)
        elif self.provider == "anthropic":
            return self._call_anthropic(user_prompt)
        elif self.provider == "local":
            return self._call_local(user_prompt)
        else:
            raise ValueError(f"不支持的 provider: {self.provider}")
    
    def _call_openai(self, prompt: str) -> dict:
        try:
            import openai
            client = openai.OpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
            resp = client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.SYSTEM_PROMPT},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=500,
            )
            content = resp.choices[0].message.content
            # 提取 JSON
            start = content.find('{')
            end = content.rfind('}') + 1
            if start >= 0 and end > start:
                return json.loads(content[start:end])
            return {"error": "无法解析LLM输出", "raw": content}
        except ImportError:
            return {"error": "未安装 openai 库，运行: pip install openai"}
        except Exception as e:
            return {"error": str(e)}
    
    def _call_anthropic(self, prompt: str) -> dict:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=self.api_key)
            resp = client.messages.create(
                model=self.model,
                system=self.SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=0.3,
            )
            content = resp.content[0].text
            start = content.find('{')
            end = content.rfind('}') + 1
            if start >= 0 and end > start:
                return json.loads(content[start:end])
            return {"error": "无法解析LLM输出", "raw": content}
        except ImportError:
            return {"error": "未安装 anthropic 库，运行: pip install anthropic"}
        except Exception as e:
            return {"error": str(e)}
    
    def _call_local(self, prompt: str) -> dict:
        """调用本地部署的模型（如 Ollama / vLLM）"""
        import urllib.request
        url = self.base_url or "http://localhost:11434/api/generate"
        
        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "system": self.SYSTEM_PROMPT,
            "stream": False,
        }).encode()
        
        req = urllib.request.Request(
            url,
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read())
                content = result.get("response", "")
                start = content.find('{')
                end = content.rfind('}') + 1
                if start >= 0 and end > start:
                    return json.loads(content[start:end])
                return {"error": "无法解析本地模型输出", "raw": content}
        except Exception as e:
            return {"error": str(e)}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 统一入口
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def analyze_game_state(context: GameContext, mode: str = "rule") -> dict:
    """
    统一分析入口
    
    Args:
        context: GameContext 对象
        mode: "rule" 使用规则引擎, "llm" 使用大模型
    """
    if mode == "rule":
        analyzer = RuleEngineAnalyzer()
    elif mode == "llm":
        analyzer = LLMAnalyzer()
    else:
        raise ValueError(f"未知模式: {mode}")
    
    return analyzer.analyze(context)


if __name__ == "__main__":
    import sys
    # 修复 Windows GBK 编码问题
    sys.stdout.reconfigure(encoding='utf-8')
    
    # 测试规则引擎
    test_ctx = GameContext(
        health_pct=15.5,
        gold=200,
        season="春",
        day=15,
        hour=22,
        minute=0,
        location="矿井入口",
        in_dungeon=True,
        dungeon_floor=20,
        bombs_in_inventory=0,
    )
    
    result = analyze_game_state(test_ctx, mode="rule")
    print(json.dumps(result, ensure_ascii=False, indent=2))
