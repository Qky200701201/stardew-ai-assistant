"""
星露谷物语 (Stardew Valley) 内存读取器
通过 ReadProcessMemory 直接读取游戏关键状态数据

使用前：
1. 打开星露谷物语
2. 用 Cheat Engine 扫描并定位你的数据（见下方说明）
3. 把找到的基址/偏移填入 CONFIG 区域
"""

import ctypes
import ctypes.wintypes
import json
import time
import sys
from dataclasses import dataclass, asdict
from typing import Optional

# ─── Windows API ───
kernel32 = ctypes.windll.kernel32

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CONFIG — 用 Cheat Engine 找到这些地址后填入
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# 方法A：静态基址 + 偏移（游戏重启后可能变化，需重新扫描）
# 示例结构（实际值需用 CE 确认）：
#   BaseAddress + 0xXXXX = PlayerData 指针
#     → Gold (int)
#     → Health (int)
#     → MaxHealth (int)
#     → CurrentDay (int)
#     → CurrentHour (int)
#     → CurrentMinute (int)
#     → PlayerX (int)  地图坐标
#     → PlayerY (int)
#     → Season (int)   0=春 1=夏 2=秋 3=冬
#     → DayOfWeek (int)  0-6

GAME_BASE_ADDRESS = 0x0000000000000000  # ← 替换为实际基址 (64位进程用 int, 32位也用 int)
PLAYER_OFFSET = 0x00000000              # ← PlayerData 相对基址的偏移
GOLD_OFFSET = 0x0000                    # ← 从 PlayerData 到 Gold 的偏移
HEALTH_OFFSET = 0x0000                  # ← 当前血量
MAX_HEALTH_OFFSET = 0x0000              # ← 最大血量
DAY_OFFSET = 0x0000                     # ← 当前天数
HOUR_OFFSET = 0x0000                    # ← 当前小时 (0-40, 游戏内时间)
MINUTE_OFFSET = 0x0000                  # ← 当前分钟
COORD_X_OFFSET = 0x0000                 # ← X 坐标
COORD_Y_OFFSET = 0x0000                 # ← Y 坐标
SEASON_OFFSET = 0x0000                  # ← 季节
DOW_OFFSET = 0x0000                     # ← 星期几

# 方法B：动态指针链（更稳定，推荐）
# 在 CE 中找到: StardewValley.exe + offset -> ... -> 你的值
# 格式: [(层1偏移), (层2偏移), (层3偏移), ...]
PLAYER_POINTER_CHAIN = []               # ← 例如 [0x180, 0x2C0, 0x40]

# 如果只用静态基址，设这个为 True
USE_STATIC_BASE = True


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 数据结构
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@dataclass
class GameState:
    gold: int = 0
    health: int = 0
    max_health: int = 0
    health_pct: float = 0.0
    day: int = 1
    hour: int = 6
    minute: int = 0
    season: int = 0          # 0=春 1=夏 2=秋 3=冬
    day_of_week: int = 0     # 0=周一
    coord_x: int = 0
    coord_y: int = 0
    location_name: str = "农场"
    in_menu: bool = False
    is_farming: bool = False
    current_weapon: int = 0
    current_tool: int = 0     # 0=斧 1=镐 2=锄头 3=水壶 4=种子

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)


SEASON_NAMES = ["春", "夏", "秋", "冬"]
DOW_NAMES = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
TOOL_NAMES = ["斧头", "镐子", "锄头", "水壶", "种子", "鱼竿", "炸弹"]

GAME_LOCATIONS = {
    (-1, -1): "农场",
    (0, 0): "鹈鹕镇",
    (100, 200): "森林",
    (200, 500): "沙漠",
    (400, 300): "矿井",
    (600, 600): "海边",
    (800, 200): "矿山",
    (1000, 800): "沼泽",
}


def get_location_name(x: int, y: int) -> str:
    """根据坐标粗略判断位置"""
    if -10 <= x <= 10 and -10 <= y <= 10:
        return "农场"
    if -50 <= x <= 50 and 200 <= y <= 300:
        return "鹈鹕镇"
    if 50 <= x <= 200 and 150 <= y <= 300:
        return "森林"
    if 350 <= x <= 450 and 250 <= y <= 350:
        return "矿井入口"
    if 750 <= x <= 850 and 550 <= y <= 650:
        return "海滩"
    if -100 <= x <= 0 and 700 <= y <= 800:
        return "下水道"
    return f"地图({x},{y})"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 核心读取函数
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def find_stardew_process() -> Optional[int]:
    """查找星露谷物语进程 ID"""
    from ctypes.wintypes import DWORD
    
    pid = DWORD(0)
    
    def enum_windows(hwnd, param):
        result = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if result and pid.value == param[0]:
            return False
        return True
    
    # 先尝试常见进程名匹配
    import subprocess
    try:
        out = subprocess.check_output(
            ['tasklist', '/FI', 'IMAGENAME eq Stardew Valley.exe', '/FO', 'CSV'],
            stderr=subprocess.DEVNULL
        ).decode('gbk', errors='replace')
        for line in out.strip().split('\n'):
            if 'Stardew Valley.exe' in line:
                parts = line.replace('"', '').split(',')
                for p in parts:
                    if p.isdigit():
                        return int(p)
    except:
        pass
    
    # 也试试 OpenHarvest (开源重制版)
    try:
        out = subprocess.check_output(
            ['tasklist', '/FI', 'IMAGENAME eq OpenHarvest.exe', '/FO', 'CSV'],
            stderr=subprocess.DEVNULL
        ).decode('gbk', errors='replace')
        for line in out.strip().split('\n'):
            if 'OpenHarvest' in line:
                parts = line.replace('"', '').split(',')
                for p in parts:
                    if p.isdigit():
                        return int(p)
    except:
        pass
    
    return None


def read_memory(pid: int, address: int, size: int = 4) -> Optional[int]:
    """
    从指定进程的指定地址读取整数
    
    Args:
        pid: 目标进程 ID
        address: 内存地址
        size: 读取字节数 (1/2/4/8)
    
    Returns:
        读取到的整数值，失败返回 None
    """
    # 打开进程
    h_process = kernel32.OpenProcess(
        PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
        False,
        pid
    )
    if not h_process:
        return None
    
    try:
        buffer = ctypes.create_string_buffer(size)
        bytes_read = ctypes.c_size_t(0)
        
        success = kernel32.ReadProcessMemory(
            h_process,
            ctypes.c_void_p(address),
            buffer,
            size,
            ctypes.byref(bytes_read)
        )
        
        if not success or bytes_read.value != size:
            return None
        
        # 根据 size 解析不同大小的整数
        if size == 1:
            return ctypes.c_int8(buffer.raw[0]).value
        elif size == 2:
            return ctypes.c_int16(ctypes.cast(buffer, ctypes.POINTER(ctypes.c_int16)).contents.value)
        elif size == 4:
            return ctypes.c_int32(ctypes.cast(buffer, ctypes.POINTER(ctypes.c_int32)).contents.value)
        elif size == 8:
            return ctypes.c_int64(ctypes.cast(buffer, ctypes.POINTER(ctypes.c_int64)).contents.value)
        else:
            return None
            
    finally:
        kernel32.CloseHandle(h_process)


def resolve_pointer_chain(pid: int, base_addr: int, chain: list, read_size: int = 8) -> Optional[int]:
    """
    解析指针链，获取最终地址的值
    
    例如 chain = [0x180, 0x2C0, 0x40] 表示:
    addr1 = base + 0x180  → 读到指针P1
    addr2 = P1 + 0x2C0    → 读到指针P2  
    addr3 = P2 + 0x40     → 读到最终值
    """
    current_addr = base_addr
    
    for i, offset in enumerate(chain[:-1]):
        addr = current_addr + offset
        ptr = read_memory(pid, addr, read_size)
        if ptr is None:
            return None
        current_addr = ptr
    
    # 最后一步读实际值
    final_addr = current_addr + chain[-1]
    return read_memory(pid, final_addr, read_size)


def read_game_state(pid: int) -> GameState:
    """读取完整游戏状态"""
    state = GameState()
    
    if USE_STATIC_BASE and GAME_BASE_ADDRESS and PLAYER_OFFSET:
        player_base = GAME_BASE_ADDRESS + PLAYER_OFFSET
        
        # 逐个读取字段
        val = read_memory(pid, player_base + GOLD_OFFSET, 4)
        if val is not None: state.gold = val
        
        val = read_memory(pid, player_base + HEALTH_OFFSET, 4)
        if val is not None: 
            state.health = val
            if state.max_health > 0:
                state.health_pct = val / state.max_health * 100
        
        val = read_memory(pid, player_base + MAX_HEALTH_OFFSET, 4)
        if val is not None: state.max_health = val
        
        val = read_memory(pid, player_base + DAY_OFFSET, 4)
        if val is not None: state.day = val
        
        val = read_memory(pid, player_base + HOUR_OFFSET, 4)
        if val is not None: state.hour = val
        
        val = read_memory(pid, player_base + MINUTE_OFFSET, 4)
        if val is not None: state.minute = val
        
        val = read_memory(pid, player_base + COORD_X_OFFSET, 4)
        if val is not None: state.coord_x = val
        
        val = read_memory(pid, player_base + COORD_Y_OFFSET, 4)
        if val is not None: state.coord_y = val
        
        val = read_memory(pid, player_base + SEASON_OFFSET, 4)
        if val is not None: state.season = val
        
        val = read_memory(pid, player_base + DOW_OFFSET, 4)
        if val is not None: state.day_of_week = val
        
        state.location_name = get_location_name(state.coord_x, state.coord_y)
    
    elif PLAYER_POINTER_CHAIN:
        # 使用指针链方式
        # 这里需要扩展为按字段分别解析指针链
        # 简化版：假设所有字段共享同一个 PlayerData 指针链
        player_data_ptr = resolve_pointer_chain(pid, GAME_BASE_ADDRESS, PLAYER_POINTER_CHAIN, 8)
        if player_data_ptr:
            val = read_memory(pid, player_data_ptr + GOLD_OFFSET, 4)
            if val is not None: state.gold = val
            # ... 其他字段同理
            
    return state


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AI 分析引擎
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def analyze_state(state: GameState) -> dict:
    """
    对游戏状态进行分析，生成 AI 建议
    
    这是一个规则引擎版本，后续可以替换为 LLM 推理
    """
    suggestions = []
    warnings = []
    urgency = "low"  # low / medium / high
    
    info = {
        "time": f"{SEASON_NAMES[state.season]}天{state.day}日 {state.hour}:{state.minute:02d} {DOW_NAMES[state.day_of_week]}",
        "location": state.location_name,
        "health_pct": round(state.health_pct, 1),
        "gold": state.gold,
    }
    
    # --- 健康检查 ---
    if state.health_pct < 20:
        warnings.append(f"⚠️ 血量危险！仅剩 {state.health}/{state.max_health}，立即回城或吃药")
        urgency = "high"
    elif state.health_pct < 50:
        warnings.append(f"血量偏低 ({state.health_pct}%)，建议休息补充")
        urgency = "medium"
    
    # --- 时间管理 ---
    # 星露谷时间：早上6点出门，晚上9-10点自动回家
    # 游戏内一小时 = 现实72秒
    game_hour_real = state.hour + state.minute / 60.0
    
    if game_hour_real >= 21.5:  # 晚上9:30以后
        warnings.append("⏰ 太晚了！快回家，否则会晕倒丢钱")
        urgency = max(urgency, "high")
    elif game_hour_real >= 20:
        suggestions.append("快10点了，考虑收工回家")
    
    if state.hour <= 6 and state.gold > 0:
        suggestions.append("新的一天开始了，先去浇水和收割作物")
    
    # --- 经济建议 ---
    if state.gold < 500:
        suggestions.append("金币不多，建议卖作物或挖矿赚些钱")
    elif state.gold > 10000:
        suggestions.append("资金充裕，可以考虑升级工具或买鸡")
    
    # --- 地点相关建议 ---
    if state.location_name == "矿井入口" and state.gold >= 50:
        suggestions.append("带够食物，下矿记得买火把")
    
    if state.location_name == "农场":
        suggestions.append("农场待命状态，检查作物是否需要浇水")
    
    # --- 综合建议 ---
    result = {
        "info": info,
        "warnings": warnings,
        "suggestions": suggestions,
        "urgency": urgency,
        "raw_state": state.to_json(),
    }
    
    return result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 主循环
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def main():
    print("=" * 50)
    print("星露谷物语内存读取器 v1.0")
    print("=" * 50)
    print("\n正在查找星露谷物语进程...")
    
    pid = find_stardew_process()
    if pid is None:
        print("[错误] 未找到星露谷物语进程！")
        print("\n请先启动游戏，然后按回车重试。")
        input()
        pid = find_stardew_process()
        if pid is None:
            print("仍然找不到进程，退出。")
            return
    
    print(f"[OK] 找到进程 PID={pid}")
    print(f"基址配置: {'静态基址' if USE_STATIC_BASE else '指针链'}")
    print(f"按 Ctrl+C 停止\n")
    
    frame_count = 0
    last_time = time.time()
    
    try:
        while True:
            state = read_game_state(pid)
            
            if state.gold == 0 and state.health == 0 and state.day == 1:
                # 可能是初始值，说明读取失败
                time.sleep(0.1)
                continue
            
            analysis = analyze_state(state)
            
            # 性能统计
            frame_count += 1
            now = time.time()
            fps = frame_count / (now - last_time)
            
            # 输出
            print(f"\r[{fps:.0f}Hz] "
                  f"金币:{state.gold} "
                  f"HP:{state.health}/{state.max_health} "
                  f"第{state.day}天 {state.hour}:{state.minute:02d} "
                  f"{SEASON_NAMES[state.season]} "
                  f"📍{state.location_name} "
                  f"| ⚡{analysis['urgency']} ", end="", flush=True)
            
            if analysis['warnings']:
                print(f"\n  ⚠️ {' | '.join(analysis['warnings'])}")
            
            if frame_count % 10 == 0 and analysis['suggestions']:
                print(f"\n  💡 {' | '.join(analysis['suggestions'])}")
            
            # 可选：保存 JSON 供外部消费
            # with open('game_state.json', 'w') as f:
            #     f.write(json.dumps(analysis, ensure_ascii=False, indent=2))
            
            time.sleep(0.05)  # ~20 FPS 轮询
            
    except KeyboardInterrupt:
        print(f"\n\n已停止。共读取 {frame_count} 帧，平均延迟测量中...")


if __name__ == "__main__":
    main()
