"""
星露谷物语 AI 助手 — HUD 浮窗界面
使用 tkinter（标准库）实现半透明悬浮窗口，无需额外依赖
"""

import sys
import json
import threading
import time
from tkinter import Tk, Label, Frame, Canvas, NW, TOP, BOTH, X, LEFT, RIGHT, S, ANCHOR
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8')


class GameHUD:
    """游戏状态悬浮窗"""
    
    def __init__(self):
        self.root = Tk()
        self.root.title("星露谷 AI 助手")
        self.root.attributes('-topmost', True)  # 始终置顶
        self.root.attributes('-alpha', 0.92)   # 半透明
        self.root.configure(bg='#1a1a2e')
        
        # 窗口大小和位置
        self.WIDTH = 320
        self.HEIGHT = 480
        
        # 获取屏幕尺寸
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        
        # 默认放在屏幕右侧
        x_pos = screen_w - self.WIDTH - 20
        y_pos = 100
        self.root.geometry(f"{self.WIDTH}x{self.HEIGHT}+{x_pos}+{y_pos}")
        
        # 禁止调整大小
        self.root.resizable(False, False)
        
        # 创建主框架
        self.main_frame = Frame(self.root, bg='#1a1a2e')
        self.main_frame.pack(fill=BOTH, expand=True, padx=10, pady=10)
        
        # --- 标题栏 ---
        title_frame = Frame(self.main_frame, bg='#16213e', height=40)
        title_frame.pack(fill=X, pady=(0, 8))
        self.title_label = Label(
            title_frame, 
            text="🌾 星露谷 AI 助手",
            bg='#16213e',
            fg='#e0e0e0',
            font=('', 14, 'bold')
        )
        self.title_label.pack(pady=5)
        
        # --- 状态信息区 ---
        self.info_frame = Frame(self.main_frame, bg='#0f3460')
        self.info_frame.pack(fill=X, pady=(0, 8))
        
        # 季节/日期
        self.season_label = Label(
            self.info_frame,
            text="春 第1天 周一",
            bg='#0f3460',
            fg='#e94560',
            font=('', 12, 'bold')
        )
        self.season_label.pack(side=LEFT, padx=10, pady=5)
        
        # 时间
        self.time_label = Label(
            self.info_frame,
            text="06:00",
            bg='#0f3460',
            fg='#e94560',
            font=('', 12, 'bold')
        )
        self.time_label.pack(side=RIGHT, padx=10, pady=5)
        
        # --- 血量条 ---
        self.hp_frame = Frame(self.main_frame, bg='#1a1a2e')
        self.hp_frame.pack(fill=X, pady=(0, 8))
        
        self.hp_text = Label(
            self.hp_frame,
            text="❤️ HP: 20/20 (100%)",
            bg='#1a1a2e',
            fg='#ffffff',
            font=('', 11)
        )
        self.hp_text.pack(side=LEFT, padx=10)
        
        self.hp_canvas = Canvas(
            self.hp_frame,
            width=180,
            height=16,
            bg='#333355',
            highlightthickness=0
        )
        self.hp_canvas.pack(side=RIGHT, padx=10, pady=5)
        self.hp_bar = self.hp_canvas.create_rectangle(2, 2, 0, 14, fill='#e94560')
        
        # --- 金币 ---
        self.gold_label = Label(
            self.main_frame,
            text="💰 金币: 0",
            bg='#1a1a2e',
            fg='#ffd700',
            font=('', 12)
        )
        self.gold_label.pack(pady=(0, 8))
        
        # --- 位置 ---
        self.location_label = Label(
            self.main_frame,
            text="📍 农场",
            bg='#1a1a2e',
            fg='#00d2ff',
            font=('', 12)
        )
        self.location_label.pack(pady=(0, 8))
        
        # --- 紧急程度指示器 ---
        self.urgency_frame = Frame(self.main_frame, bg='#1a1a2e')
        self.urgency_frame.pack(fill=X, pady=(0, 8))
        
        self.urgency_dot = Label(
            self.urgency_frame,
            text="●",
            bg='#1a1a2e',
            fg='#4ade80',
            font=('', 20)
        )
        self.urgency_dot.pack(side=LEFT, padx=10)
        
        self.urgency_text = Label(
            self.urgency_frame,
            text="正常",
            bg='#1a1a2e',
            fg='#4ade80',
            font=('', 11)
        )
        self.urgency_text.pack(side=LEFT)
        
        # --- 警告区域 ---
        self.warning_frame = Frame(self.main_frame, bg='#3a1a1a', highlightbackground='#e94560', highlightthickness=1)
        self.warning_frame.pack(fill=X, pady=(0, 8))
        
        self.warning_label = Label(
            self.warning_frame,
            text="",
            bg='#3a1a1a',
            fg='#ff6b6b',
            font=('', 11, 'bold'),
            wraplength=280,
            justify=LEFT
        )
        self.warning_label.pack(padx=10, pady=8)
        
        # --- 建议区域 ---
        self.suggest_frame = Frame(self.main_frame, bg='#1a1a2e')
        self.suggest_frame.pack(fill=BOTH, expand=True)
        
        self.suggest_title = Label(
            self.suggest_frame,
            text="💡 建议",
            bg='#1a1a2e',
            fg='#ffd700',
            font=('', 11, 'bold')
        )
        self.suggest_title.pack(anchor=NW, padx=10, pady=(5, 2))
        
        self.suggest_text = Label(
            self.suggest_frame,
            text="等待数据输入...",
            bg='#1a1a2e',
            fg='#a0a0c0',
            font=('', 10),
            wraplength=290,
            justify=LEFT
        )
        self.suggest_text.pack(anchor=NW, padx=10, pady=(0, 10))
        
        # --- 底部状态 ---
        self.status_label = Label(
            self.main_frame,
            text="⏳ 连接中...",
            bg='#1a1a2e',
            fg='#666688',
            font=('', 9)
        )
        self.status_label.pack(anchor=S, pady=(5, 0))
        
        # 更新队列
        self.update_queue = []
    
    def update_from_analysis(self, analysis: dict):
        """从分析结果更新 UI"""
        if not analysis or 'info' not in analysis:
            return
        
        info = analysis['info']
        
        # 季节/日期
        season_names = ["春", "夏", "秋", "冬"]
        dow_names = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        s_idx = info.get('season', 0)
        if isinstance(s_idx, str):
            try:
                s_idx = int(s_idx)
            except:
                s_idx = 0
        season_str = f"{season_names[s_idx % 4]} 第{info.get('day', 1)}天"
        dow_idx = info.get('day_of_week', 0)
        if isinstance(dow_idx, str):
            try:
                dow_idx = int(dow_idx)
            except:
                dow_idx = 0
        if 0 <= dow_idx < 7:
            season_str += f" {dow_names[dow_idx]}"
        self.season_label.config(text=season_str)
        
        # 时间
        hour = info.get('hour', 6)
        minute = info.get('minute', 0)
        self.time_label.config(text=f"{hour:02d}:{minute:02d}")
        
        # 血量
        health_pct = info.get('health_pct', 100)
        max_hp = analysis.get('max_health', 20)
        current_hp = int(max_hp * health_pct / 100) if max_hp else 0
        self.hp_text.config(text=f"❤️ HP: {current_hp}/{max_hp} ({health_pct:.0f}%)")
        
        # 血量条颜色
        if health_pct < 20:
            bar_color = '#ff0000'
        elif health_pct < 50:
            bar_color = '#ffa500'
        else:
            bar_color = '#4ade80'
        
        # 更新血量条宽度
        bar_width = max(0, int(health_pct * 1.76))
        self.hp_canvas.delete(self.hp_bar)
        self.hp_bar = self.hp_canvas.create_rectangle(2, 2, bar_width + 2, 14, fill=bar_color)
        
        # 金币
        gold = info.get('gold', 0)
        self.gold_label.config(text=f"💰 金币: {gold:,}")
        
        # 位置
        location = info.get('location', '未知')
        self.location_label.config(text=f"📍 {location}")
        
        # 紧急程度
        urgency = analysis.get('urgency', 'low')
        urgency_colors = {
            'low': ('#4ade80', '正常'),
            'medium': ('#fbbf24', '注意'),
            'high': ('#ef4444', '危险！'),
        }
        color, text = urgency_colors.get(urgency, ('#4ade80', '正常'))
        self.urgency_dot.config(fg=color)
        self.urgency_text.config(fg=color, text=text)
        
        # 警告
        warnings = analysis.get('warnings', [])
        if warnings:
            warning_text = "\n".join(warnings)
            self.warning_frame.config(bg='#3a1a1a', highlightbackground='#e94560')
        else:
            warning_text = ""
            self.warning_frame.config(bg='#1a2a1a', highlightbackground='#4ade80')
        self.warning_label.config(text=warning_text)
        
        # 建议
        suggestions = analysis.get('suggestions', [])
        if suggestions:
            suggest_text = "\n".join(f"• {s}" for s in suggestions)
        else:
            suggest_text = "当前没有特别建议"
        self.suggest_text.config(text=suggest_text)
        
        # 状态
        self.status_label.config(text=f"✅ 实时更新 | {datetime.now().strftime('%H:%M:%S')}")
    
    def set_disconnected(self):
        self.status_label.config(text="❌ 未连接到游戏", fg='#ef4444')
        self.suggest_text.config(text="请启动游戏并配置内存地址")
    
    def run(self):
        """启动主循环"""
        self.root.mainloop()


def hud_update_loop(hud: GameHUD, state_callback):
    """
    后台线程：定时调用 state_callback 获取状态并更新 HUD
    
    Args:
        hud: HUD 实例
        state_callback: 函数 -> 返回分析结果 dict
    """
    last_render = 0
    
    def tick():
        nonlocal last_render
        now = time.time()
        
        try:
            analysis = state_callback()
            if analysis:
                hud.root.after(0, hud.update_from_analysis, analysis)
        except Exception as e:
            hud.root.after(0, hud.set_disconnected)
        
        # 限制 UI 更新频率 ~10 FPS
        schedule_time = min(0.1, now - last_render)
        hud.root.after(int(schedule_time * 1000), tick)
    
    hud.root.after(100, tick)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 与 reader.py 集成示例
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def create_hud_with_reader():
    """创建带内存读取的完整 HUD"""
    from reader import find_stardew_process, read_game_state, analyze_state, GameState
    
    pid = find_stardew_process()
    if pid is None:
        print("[错误] 未找到游戏进程")
        return None
    
    hud = GameHUD()
    
    def get_state():
        state = read_game_state(pid)
        if state.gold == 0 and state.health == 0:
            return None
        analysis = analyze_state(state)
        # 注入 max_health 给 HUD
        analysis['max_health'] = state.max_health
        return analysis
    
    # 在 HUD 线程中运行
    hud_update_loop(hud, get_state)
    
    return hud


if __name__ == "__main__":
    hud = create_hud_with_reader()
    if hud:
        hud.run()
    else:
        # 演示模式：用模拟数据
        hud = GameHUD()
        
        def mock_state():
            return {
                "info": {
                    "season": 0, "day": 15, "hour": 14, "minute": 30,
                    "day_of_week": 2, "location": "矿井入口",
                    "health_pct": 45.0, "gold": 1250
                },
                "warnings": ["血量偏低，建议休息补充"],
                "suggestions": [
                    "快10点了，考虑收工回家",
                    "资金充裕！可以考虑买鸡或升级工具",
                    "带够食物，下矿记得买火把"
                ],
                "urgency": "medium",
                "max_health": 20,
            }
        
        hud_update_loop(hud, mock_state)
        hud.run()
