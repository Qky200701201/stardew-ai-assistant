# 星露谷物语 AI 助手

通过内存读取实现星露谷物语的实时 AI 游戏助手。

## 架构

```
[游戏进程] → ReadProcessMemory → GameState JSON → AI分析 → HUD浮窗
```

延迟对比：
- 截图方案: 80-250ms（截屏+视觉模型推理）
- **内存读取: 1-5ms**（直接读数值，零推理）

## 文件结构

```
stardew-memory-reader/
├── reader.py      # 内存读取核心（ReadProcessMemory）
├── analyzer.py    # AI分析引擎（规则引擎 + LLM可选）
├── hud.py         # 悬浮窗界面（tkinter）
├── CE_GUIDE.md    # Cheat Engine 地址查找指南
└── README.md      # 本文件
```

## 快速开始

### 1. 用 Cheat Engine 找到内存地址

详见 `CE_GUIDE.md`。需要找到：
- 金币 (Gold)
- 血量 (Health / MaxHealth)
- 天数、小时、分钟
- X/Y 坐标
- 季节、星期

### 2. 填入配置

编辑 `reader.py` 顶部的 CONFIG 区域：

```python
# 方式A：静态基址
GAME_BASE_ADDRESS = 0xXXXXXX0000000000  # stardewValley.exe 基址
PLAYER_OFFSET = 0xXXXX                   # PlayerData 偏移
GOLD_OFFSET = 0x40                      # Gold 相对偏移
HEALTH_OFFSET = 0x44                    # Health 相对偏移
# ... 其他字段

# 方式B：指针链（更稳定）
USE_STATIC_BASE = False
PLAYER_POINTER_CHAIN = [0x180, 0x2C0, 0x40]
```

### 3. 运行

```bash
# 先启动星露谷物语
python reader.py          # 命令行模式（纯数据输出）
python hud.py             # GUI 悬浮窗模式
```

## 功能

### 规则引擎分析 (`analyzer.py`)
- 血量危险警告
- 时间管理提醒（太晚回家）
- 经济建议
- 地点相关提示
- 库存检查（种子/炸弹/食物）
- 季节转换提醒

### LLM 深度分析（可选）
支持接入 OpenAI / Anthropic / 本地模型：

```python
from analyzer import LLMAnalyzer

llm = LLMAnalyzer(
    api_provider="openai",
    api_key="sk-xxx",
    model="gpt-4o-mini"
)
result = llm.analyze(game_context)
```

### HUD 悬浮窗 (`hud.py`)
- 半透明始终置顶窗口
- 实时显示：季节/日期/时间/位置/金币/血量条
- 紧急程度指示器（绿→黄→红）
- 警告和建议动态更新
- ~10 FPS UI 刷新

## 扩展方向

- [ ] 多帧时序分析（预测敌人移动）
- [ ] YOLO 视觉辅助（检测画面中未结构化的信息）
- [ ] 语音播报（edge-tts）
- [ ] 支持更多单机游戏
- [ ] 热键触发详细分析（Ctrl+Space）

## 注意事项

- 仅用于无反作弊的单机游戏
- 内存地址可能随游戏更新变化
- 使用 Cheat Engine 时确保游戏在前台
